/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructor;

/**
 *
 * @author dany
 */
public class Arquitecto extends Constructor{
    
    public Arquitecto(String nombre) {
        super(nombre,250, 175, 1, "Millenial Falcon");
    }
    
}
