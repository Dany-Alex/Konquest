/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Guerrero;

/**
 *
 * @author dany
 */
public class FusionGuy extends Guerrero{
    
    public FusionGuy(String nombre) {
        super(nombre, "rayos gama", 1.95, 4);
    }
    
}
