/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Guerrero;

/**
 *
 * @author dany
 */
public class Groot extends Guerrero{
    
    public Groot(String nombre) {
        super(nombre, "enredaderas trampa", 1.85, 3);
    }
    
}
