/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Guerrero;

/**
 *
 * @author dany
 */
public class Guerrero {
    public String nombre;
    public String AtaqueEspecial;
    public double factorMuerte;
    public int lugarOcupa;

    public Guerrero(String nombre, String AtaqueEspecial, double factorMuerte, int lugarOcupa) {
        this.nombre = nombre;
        this.AtaqueEspecial = AtaqueEspecial;
        this.factorMuerte = factorMuerte;
        this.lugarOcupa = lugarOcupa;
    }
    
public void generarGerrero(){

}
    
}
