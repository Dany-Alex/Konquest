/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Guerrero;

/**
 *
 * @author dany
 */
public class Magama extends Guerrero{
    
    public Magama(String nombre) {
        super(nombre, "lanzando bolas de lava", 1.75, 2);
    }
    
}
