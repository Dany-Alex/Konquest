/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Planeta;

/**
 *
 * @author dany
 */
public class Tierra extends Planeta{
    
    public Tierra(String nombre, int cantidadDinero, int cantidadConstructores, int cantidadNaves, int cantidadGerreros) {
        super(nombre, cantidadDinero, cantidadConstructores, cantidadNaves, cantidadGerreros);
    }

    
 
    
}
